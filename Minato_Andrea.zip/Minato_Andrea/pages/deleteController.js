angular.module('myApp')
    .controller('deleteController', function($scope, $state, $stateParams, dataAccess){

    });