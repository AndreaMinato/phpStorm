
angular.module('myApp')
    .controller('contactController', function($scope){
        $scope.message = 'Ti trovi nella pagina contatti.';
    });